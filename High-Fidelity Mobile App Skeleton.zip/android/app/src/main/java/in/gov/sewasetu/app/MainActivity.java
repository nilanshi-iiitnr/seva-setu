package in.gov.sewasetu.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
