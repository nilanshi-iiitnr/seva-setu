import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "in.gov.sewasetu.app",
  appName: "SEWA SETU+",
  webDir: "dist",
  backgroundColor: "#F8FAFC",
  android: {
    allowMixedContent: false,
  },
};

export default config;
