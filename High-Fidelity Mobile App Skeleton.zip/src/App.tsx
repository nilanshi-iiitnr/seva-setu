import { useState, type ReactNode } from "react";

type Screen =
  | "splash"
  | "home"
  | "report"
  | "detection"
  | "tracking"
  | "map"
  | "fund"
  | "notifications"
  | "profile"
  | "comparison";

type IconName =
  | "home"
  | "camera"
  | "route"
  | "map"
  | "wallet"
  | "bell"
  | "user"
  | "chevron"
  | "back"
  | "pin"
  | "upload"
  | "check"
  | "clock"
  | "shield"
  | "sparkles"
  | "building"
  | "heart"
  | "settings"
  | "help"
  | "document"
  | "arrow";

const iconPaths: Record<IconName, ReactNode> = {
  home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
  camera: <><path d="M4 7h3l1.5-2h7L17 7h3v12H4z" /><circle cx="12" cy="13" r="4" /></>,
  route: <><circle cx="6" cy="18" r="2" /><circle cx="18" cy="6" r="2" /><path d="M8 18h3a3 3 0 0 0 3-3V9a3 3 0 0 1 3-3" /></>,
  map: <><path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3z" /><path d="M9 3v15M15 6v15" /></>,
  wallet: <><path d="M4 6.5h15v13H4a2 2 0 0 1-2-2v-12a2 2 0 0 1 2-2h12" /><path d="M15 11h6v5h-6a2.5 2.5 0 0 1 0-5Z" /></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
  chevron: <path d="m9 18 6-6-6-6" />,
  back: <><path d="m15 18-6-6 6-6" /><path d="M9 12h10" /></>,
  pin: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
  upload: <><path d="m8 8 4-4 4 4M12 4v12" /><path d="M5 14v6h14v-6" /></>,
  check: <path d="m5 12 4 4L19 6" />,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v6l4 2" /></>,
  shield: <><path d="M12 3 4.5 6v5c0 4.8 3.1 8.1 7.5 10 4.4-1.9 7.5-5.2 7.5-10V6z" /><path d="m8.5 12 2.2 2.2 4.8-5" /></>,
  sparkles: <><path d="m12 3 1.2 3.8L17 8l-3.8 1.2L12 13l-1.2-3.8L7 8l3.8-1.2zM5 15l.8 2.2L8 18l-2.2.8L5 21l-.8-2.2L2 18l2.2-.8zM19 14l.6 1.4L21 16l-1.4.6L19 18l-.6-1.4L17 16l1.4-.6z" /></>,
  building: <><path d="M4 21V8l8-5 8 5v13M2 21h20" /><path d="M8 10h2M14 10h2M8 14h2M14 14h2M10 21v-4h4v4" /></>,
  heart: <path d="M20.8 5.7a5.5 5.5 0 0 0-7.8 0L12 6.8l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 22l8.8-8.5a5.5 5.5 0 0 0 0-7.8Z" />,
  settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></>,
  help: <><circle cx="12" cy="12" r="9" /><path d="M9.7 9a2.4 2.4 0 1 1 3.2 2.3c-.9.4-.9 1.1-.9 2M12 17h.01" /></>,
  document: <><path d="M6 3h8l4 4v14H6z" /><path d="M14 3v5h4M9 13h6M9 17h6" /></>,
  arrow: <><path d="M5 12h14M14 7l5 5-5 5" /></>,
};

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {iconPaths[name]}
    </svg>
  );
}

function Press({
  children,
  className = "",
  onClick,
  label,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  label?: string;
}) {
  return (
    <button type="button" className={className} onClick={onClick} aria-label={label}>
      {children}
    </button>
  );
}

function Logo({ light = false, compact = false }: { light?: boolean; compact?: boolean }) {
  return (
    <div className={`logo ${light ? "logo-light" : ""} ${compact ? "logo-compact" : ""}`}>
      <span className="logo-mark"><Icon name="shield" size={compact ? 18 : 28} /></span>
      <span className="logo-copy">SEWA SETU<span>+</span></span>
    </div>
  );
}

function StatusBar({ light = false }: { light?: boolean }) {
  return (
    <div className={`status-bar ${light ? "status-light" : ""}`}>
      <span>9:41</span>
      <div className="status-icons"><span className="signal">▮▮▮</span><span>◒</span><span className="battery" /></div>
    </div>
  );
}

const navItems: { screen: Screen; label: string; icon: IconName }[] = [
  { screen: "home", label: "Home", icon: "home" },
  { screen: "tracking", label: "Track", icon: "route" },
  { screen: "map", label: "Risk Map", icon: "map" },
  { screen: "notifications", label: "Updates", icon: "bell" },
  { screen: "profile", label: "Profile", icon: "user" },
];

function BottomNav({ active, go }: { active: Screen; go: (screen: Screen) => void }) {
  return (
    <nav className="bottom-nav" aria-label="Primary navigation">
      {navItems.map((item) => (
        <Press key={item.screen} onClick={() => go(item.screen)} className={`nav-item ${active === item.screen ? "active" : ""}`}>
          <span className="nav-icon"><Icon name={item.icon} size={20} /></span>
          <span>{item.label}</span>
          {item.screen === "notifications" && <i className="nav-dot" />}
        </Press>
      ))}
    </nav>
  );
}

function PageHeader({ title, subtitle, back, go, action }: { title: string; subtitle?: string; back?: Screen; go: (s: Screen) => void; action?: ReactNode }) {
  return (
    <header className="page-header">
      {back ? <Press className="icon-button" onClick={() => go(back)} label="Go back"><Icon name="back" /></Press> : <Logo compact />}
      <div className="page-heading"><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>
      {action || <span className="header-spacer" />}
    </header>
  );
}

function Card({ children, className = "", onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return onClick ? <Press className={`card ${className}`} onClick={onClick}>{children}</Press> : <div className={`card ${className}`}>{children}</div>;
}

function Splash({ go }: { go: (s: Screen) => void }) {
  return (
    <div className="splash">
      <StatusBar light />
      <div className="splash-orb orb-one" /><div className="splash-orb orb-two" />
      <div className="splash-center">
        <div className="splash-emblem"><Icon name="shield" size={49} /><span className="emblem-spark"><Icon name="sparkles" size={17} /></span></div>
        <Logo light />
        <p>Report once. Verify with AI.<br />Track every repair.</p>
      </div>
      <div className="splash-bottom">
        <Press className="get-started" onClick={() => go("home")}>Get started <Icon name="arrow" /></Press>
        <span>Citizen services, made accountable.</span>
      </div>
    </div>
  );
}

function Home({ go }: { go: (s: Screen) => void }) {
  const actions: { label: string; sub: string; icon: IconName; screen: Screen; tone: string }[] = [
    { label: "Report Hazard", sub: "AI-assisted", icon: "camera", screen: "report", tone: "blue" },
    { label: "Track Complaint", sub: "Live progress", icon: "route", screen: "tracking", tone: "teal" },
    { label: "Risk Map", sub: "Nearby alerts", icon: "map", screen: "map", tone: "amber" },
    { label: "Fund Progress", sub: "100% transparent", icon: "wallet", screen: "fund", tone: "violet" },
  ];
  return (
    <div className="screen">
      <StatusBar />
      <main className="scroll-content home-content">
        <div className="home-top">
          <Logo compact />
          <Press className="notification-button" onClick={() => go("notifications")} label="Notifications"><Icon name="bell" /><i /></Press>
        </div>
        <section className="greeting"><p>GOVERNMENT OF MAHARASHTRA · CITIZEN SERVICES</p><h1>Welcome to Sewa Setu+</h1><span>Safer roads. Faster action. Full accountability.</span></section>
        <section className="civic-score">
          <div className="score-copy"><span className="eyebrow">ROAD SAFETY SCORE</span><strong>84% Road Safety Index</strong><p>12 issues resolved this month · Up 6%</p><span className="score-update"><i /> Live ward data</span></div>
          <div className="score-ring"><div><span>84%</span><small>SAFE</small></div></div>
        </section>
        <div className="section-title"><div><h2>What would you like to do?</h2><p>Quick access to citizen services</p></div></div>
        <div className="quick-grid">
          {actions.map((action) => (
            <Card key={action.label} className={`quick-card ${action.screen === "report" ? "primary-action-card" : ""}`} onClick={() => go(action.screen)}>
              <span className={`quick-icon ${action.tone}`}><Icon name={action.icon} size={action.screen === "report" ? 29 : 22} /></span>
              <span className="quick-label">{action.label}</span><small>{action.sub}</small>
              <span className="mini-arrow"><Icon name="chevron" size={15} /></span>
            </Card>
          ))}
        </div>
        <div className="section-title row-title"><div><h2>Recent complaint</h2><p>Updated 18 minutes ago</p></div><Press className="text-button" onClick={() => go("tracking")}>View all</Press></div>
        <Card className="complaint-card" onClick={() => go("tracking")}>
          <img src="https://images.unsplash.com/photo-1741996951019-a041d0477c82?auto=format&fit=crop&w=220&q=80" alt="Cracked asphalt on a damaged road" />
          <div className="complaint-info"><div><span className="status-pill verified">Verified by AI</span><small>#SSP-240218</small></div><strong>Deep pothole on Baner Road</strong><p><Icon name="pin" size={13} /> Near Jupiter Hospital, Pune</p><div className="progress-mini"><i /><i /><i /><i className="empty" /><i className="empty" /></div></div>
        </Card>
      </main>
      <Press className="ai-assistant" onClick={() => go("report")} label="Open AI civic assistant"><span><Icon name="sparkles" size={20} /></span><b>Ask SETU AI</b><i /></Press>
      <BottomNav active="home" go={go} />
    </div>
  );
}

function Report({ go }: { go: (s: Screen) => void }) {
  return (
    <div className="screen">
      <StatusBar />
      <main className="scroll-content">
        <PageHeader title="Report a hazard" subtitle="Step 1 of 2" back="home" go={go} />
        <section className="intro-block"><span className="ai-chip"><Icon name="sparkles" size={14} /> AI-ASSISTED REPORTING</span><h2>Show us what needs attention</h2><p>Take a clear photo. Our AI will identify the hazard and assess its severity.</p></section>
        <Card className="capture-area">
          <div className="scan-corner top-left" /><div className="scan-corner top-right" /><div className="scan-corner bottom-left" /><div className="scan-corner bottom-right" />
          <span className="camera-orb"><Icon name="camera" size={31} /></span>
          <strong>Capture the hazard</strong><p>Keep the issue centered and well-lit</p>
          <Press className="secondary-button" onClick={() => go("detection")}><Icon name="upload" size={17} /> Upload from gallery</Press>
        </Card>
        <Card className="location-card">
          <span className="location-icon"><Icon name="pin" /></span>
          <div><span>LOCATION AUTO-DETECTED</span><strong>Baner Road, Pune</strong><p>18.5590° N, 73.7868° E · Accuracy 4m</p></div>
          <span className="live-dot">Live</span>
        </Card>
        <div className="privacy-note"><Icon name="shield" size={17} /><p>Your photo and location are used only to verify and resolve this civic issue.</p></div>
      </main>
      <div className="action-footer"><Press className="primary-button capture-button" onClick={() => go("detection")}><span className="shutter" /> Capture photo</Press></div>
    </div>
  );
}

function Detection({ go }: { go: (s: Screen) => void }) {
  return (
    <div className="screen">
      <StatusBar />
      <main className="scroll-content detection-content">
        <PageHeader title="AI analysis" subtitle="Step 2 of 2" back="report" go={go} />
        <div className="image-preview">
          <img src="https://images.unsplash.com/photo-1741996951019-a041d0477c82?auto=format&fit=crop&w=900&q=85" alt="Cracked asphalt analyzed by the app" />
          <div className="detection-box"><span>ROAD DAMAGE</span></div>
          <span className="image-check"><Icon name="check" size={16} /></span>
          <div className="image-caption"><Icon name="sparkles" size={15} /> AI scan complete in 2.4s</div>
        </div>
        <Card className="result-card">
          <div className="result-head"><div><span className="eyebrow">HAZARD IDENTIFIED</span><h2>Deep road pothole</h2></div><span className="severity severity-high">HIGH SEVERITY</span></div>
          <div className="confidence"><div><span>AI confidence</span><strong>96%</strong></div><div className="confidence-track"><i /></div></div>
          <div className="metrics">
            <div><span>Est. width</span><strong>68 cm</strong></div>
            <div><span>Risk level</span><strong className="high">High</strong></div>
            <div><span>Road type</span><strong>Arterial</strong></div>
          </div>
          <div className="severity-scale"><small>SEVERITY SCALE</small><span className="severity severity-high">High</span><span className="severity severity-medium">Medium</span><span className="severity severity-low">Low</span></div>
        </Card>
        <Card className="authority-card"><span><Icon name="building" /></span><div><small>ROUTING TO</small><strong>Pune Municipal Corporation</strong><p>Road Maintenance · Ward 9</p></div><i><Icon name="check" size={14} /></i></Card>
        <div className="smart-note"><Icon name="sparkles" size={17} /><p><strong>Smart duplicate check</strong>No matching complaint found within 120 metres.</p></div>
      </main>
      <div className="action-footer stacked"><Press className="primary-button" onClick={() => go("tracking")}>Submit report <Icon name="arrow" size={18} /></Press><Press className="footer-link" onClick={() => go("report")}>Retake photo</Press></div>
    </div>
  );
}

function Tracking({ go }: { go: (s: Screen) => void }) {
  const steps = [
    ["Reported", "Today, 9:42 AM", true],
    ["AI Verified", "Today, 9:43 AM", true],
    ["Assigned to PMC", "Today, 10:18 AM", true],
    ["Repair in progress", "Crew expected by 4:30 PM", false],
    ["Citizen confirmation", "Waiting for completion", false],
  ] as const;
  return (
    <div className="screen">
      <StatusBar />
      <main className="scroll-content">
        <PageHeader title="Complaint tracking" subtitle="#SSP-240218" back="home" go={go} />
        <Card className="tracking-hero">
          <div className="tracking-title"><span className="status-pill assigned">CREW ASSIGNED</span><span>Updated 18 min ago</span></div>
          <h2>Deep pothole on Baner Road</h2><p><Icon name="pin" size={14} /> Near Jupiter Hospital, Pune</p>
          <div className="sla-box"><div className="sla-icon"><Icon name="clock" /></div><div><span>LIVE SLA COUNTDOWN</span><strong>06 : 42 : 18</strong></div><small>hrs&nbsp;&nbsp; min&nbsp;&nbsp; sec</small></div>
        </Card>
        <div className="section-title"><div><h2>Resolution journey</h2><p>Every update is time-stamped</p></div></div>
        <Card className="timeline-card">
          {steps.map(([title, detail, done], index) => (
            <div className={`timeline-step ${done ? "done" : ""} ${index === 3 ? "current" : ""}`} key={title}>
              <div className="timeline-marker">{done ? <Icon name="check" size={13} /> : index + 1}</div>
              <div><strong>{title}</strong><p>{detail}</p>{index === 2 && <span className="crew-chip"><Icon name="building" size={12} /> Ward 9 · Crew R-14</span>}</div>
              {index === 3 && <span className="in-progress">IN PROGRESS</span>}
            </div>
          ))}
        </Card>
        <Card className="officer-card"><span className="officer-avatar">RK</span><div><small>ASSIGNED ENGINEER</small><strong>Rajesh Kulkarni</strong><p>PMC Road Maintenance</p></div><Press className="message-button">Message</Press></Card>
        <Card className="comparison-link" onClick={() => go("comparison")}>
          <div className="comparison-thumbs"><img src="https://images.unsplash.com/photo-1741996951019-a041d0477c82?auto=format&fit=crop&w=180&q=80" alt="Road before repair" /><img src="https://images.unsplash.com/photo-1648662594772-786f95b9e58b?auto=format&fit=crop&w=180&q=80" alt="Road after repair" /></div>
          <div><span className="status-pill verified">VERIFIED REPAIR</span><strong>Before vs after repair</strong><p>See the authority’s completion evidence</p></div>
          <Icon name="chevron" size={18} />
        </Card>
      </main>
      <BottomNav active="tracking" go={go} />
    </div>
  );
}

function RiskMap({ go }: { go: (s: Screen) => void }) {
  return (
    <div className="screen map-screen">
      <StatusBar />
      <div className="map-canvas">
        <div className="map-road road-a" /><div className="map-road road-b" /><div className="map-road road-c" /><div className="map-road road-d" />
        <span className="map-label label-baner">Baner Road</span><span className="map-label label-aundh">Aundh</span><span className="map-label label-balewadi">Balewadi</span>
        <div className="heat heat-one" /><div className="heat heat-two" /><div className="heat heat-three" />
        <span className="hazard-pin red pin-one">7</span><span className="hazard-pin amber pin-two">3</span><span className="hazard-pin teal pin-three">2</span>
        <span className="user-location"><i /></span>
      </div>
      <div className="map-overlay-top">
        <PageHeader title="Civic risk map" subtitle="Live hazards around you" back="home" go={go} action={<Press className="icon-button"><Icon name="map" /></Press>} />
        <div className="map-filters"><Press className="filter active">All hazards</Press><Press className="filter"><i className="red" /> High</Press><Press className="filter"><i className="amber" /> Medium</Press><Press className="filter"><i className="teal" /> Low</Press></div>
      </div>
      <div className="map-bottom">
        <Card className="risk-score-card">
          <div className="risk-score"><span>72</span><small>/100</small></div>
          <div><span className="eyebrow">ROAD RISK SCORE</span><h2>Elevated risk nearby</h2><p>12 active hazards within 2 km</p></div>
          <Icon name="chevron" />
        </Card>
        <div className="map-legend"><span><i className="red" /> High risk</span><span><i className="amber" /> Medium</span><span><i className="teal" /> Resolved</span></div>
      </div>
      <BottomNav active="map" go={go} />
    </div>
  );
}

function Fund({ go }: { go: (s: Screen) => void }) {
  return (
    <div className="screen">
      <StatusBar />
      <main className="scroll-content fund-content">
        <PageHeader title="Infrastructure Recovery Fund" subtitle="Open, traceable, accountable" back="home" go={go} />
        <Card className="fund-hero">
          <div className="fund-symbol"><Icon name="wallet" size={25} /></div>
          <span>INFRASTRUCTURE RECOVERY FUND</span><h2>₹42.8 lakh</h2><p>raised of ₹60 lakh goal</p>
          <div className="fund-track"><i /></div><div className="fund-numbers"><span>71% funded</span><span>18 days left</span></div>
        </Card>
        <div className="fund-stats">
          <Card><span className="stat-icon people"><Icon name="heart" /></span><strong>1,842</strong><p>Citizen contributors</p></Card>
          <Card><span className="stat-icon csr"><Icon name="building" /></span><strong>₹18.2L</strong><p>CSR contribution</p></Card>
        </div>
        <div className="section-title row-title"><div><h2>Where funds are going</h2><p>Verified project allocation</p></div><span className="status-pill verified">LIVE</span></div>
        <Card className="allocation-card">
          <div className="allocation-row"><span className="alloc-icon blue"><Icon name="route" /></span><div><strong>Road restoration</strong><p>32 repairs · 18 completed</p></div><b>₹24.6L</b></div>
          <div className="alloc-bar blue"><i /></div>
          <div className="allocation-row"><span className="alloc-icon teal"><Icon name="shield" /></span><div><strong>Drainage upgrades</strong><p>12 sites · 7 completed</p></div><b>₹11.4L</b></div>
          <div className="alloc-bar teal"><i /></div>
          <div className="allocation-row"><span className="alloc-icon amber"><Icon name="sparkles" /></span><div><strong>Street lighting</strong><p>86 lights · 61 replaced</p></div><b>₹6.8L</b></div>
          <div className="alloc-bar amber"><i /></div>
        </Card>
        <Card className="transparency-card"><span><Icon name="shield" /></span><div><strong>Built for transparency</strong><p>Every rupee is linked to a verified work order and public audit trail.</p><Press className="text-button">View public ledger <Icon name="arrow" size={14} /></Press></div></Card>
      </main>
      <div className="action-footer"><Press className="primary-button"><Icon name="heart" size={18} /> Contribute securely</Press></div>
    </div>
  );
}

function Notifications({ go }: { go: (s: Screen) => void }) {
  const updates: { icon: IconName; tone: string; title: string; text: string; time: string; screen?: Screen }[] = [
    { icon: "building", tone: "blue", title: "Repair crew assigned", text: "Crew R-14 has been assigned to complaint #SSP-240218.", time: "18 min ago", screen: "tracking" },
    { icon: "clock", tone: "amber", title: "SLA reminder", text: "Your Baner Road complaint is due for repair within 6 hours.", time: "1 hr ago", screen: "tracking" },
    { icon: "check", tone: "teal", title: "Issue resolved", text: "Streetlight #SSP-239842 was repaired. Please confirm the work.", time: "Yesterday" },
    { icon: "document", tone: "violet", title: "Authority response", text: "PMC added a note to your drainage complaint in Aundh.", time: "2 days ago" },
  ];
  return (
    <div className="screen">
      <StatusBar />
      <main className="scroll-content">
        <PageHeader title="Updates" subtitle="4 unread notifications" back="home" go={go} action={<Press className="text-button">Mark all read</Press>} />
        <div className="notification-tabs"><Press className="active">All <span>4</span></Press><Press>Status</Press><Press>Reminders</Press></div>
        <div className="today-label">TODAY</div>
        <div className="updates-list">
          {updates.map((update, index) => (
            <Card key={update.title} className={`update-card ${index < 2 ? "unread" : ""}`} onClick={update.screen ? () => go(update.screen!) : undefined}>
              <span className={`update-icon ${update.tone}`}><Icon name={update.icon} /></span>
              <div><div className="update-title"><strong>{update.title}</strong><small>{update.time}</small></div><p>{update.text}</p>{index === 0 && <span className="inline-link">Track progress <Icon name="arrow" size={13} /></span>}</div>
            </Card>
          ))}
        </div>
        <Card className="notification-settings"><span><Icon name="bell" /></span><div><strong>Stay informed</strong><p>SLA and authority alerts are enabled</p></div><Press className="text-button">Manage</Press></Card>
      </main>
      <BottomNav active="notifications" go={go} />
    </div>
  );
}

function Profile({ go }: { go: (s: Screen) => void }) {
  const items: { label: string; sub: string; icon: IconName; tone: string; screen?: Screen }[] = [
    { label: "My complaints", sub: "8 active · 12 resolved", icon: "document", tone: "blue", screen: "tracking" },
    { label: "My contributions", sub: "₹2,500 donated to 3 projects", icon: "heart", tone: "teal", screen: "fund" },
    { label: "Settings", sub: "Language, privacy, notifications", icon: "settings", tone: "violet" },
    { label: "Help & support", sub: "FAQs and citizen helpline", icon: "help", tone: "amber" },
  ];
  return (
    <div className="screen">
      <StatusBar />
      <main className="scroll-content profile-content">
        <PageHeader title="Profile" subtitle="Your civic impact" back="home" go={go} />
        <section className="profile-hero"><div className="avatar">AM<span><Icon name="check" size={11} /></span></div><h2>Aanya Mehta</h2><p>Verified citizen · Pune, Maharashtra</p><div className="member-chip"><Icon name="shield" size={14} /> Member since March 2023</div></section>
        <div className="profile-stats"><div><strong>20</strong><span>Reports</span></div><div><strong>12</strong><span>Resolved</span></div><div><strong>84</strong><span>Civic score</span></div></div>
        <div className="section-title"><div><h2>Your account</h2></div></div>
        <Card className="profile-menu">
          {items.map((item) => (
            <Press key={item.label} className="menu-row" onClick={item.screen ? () => go(item.screen!) : undefined}>
              <span className={`menu-icon ${item.tone}`}><Icon name={item.icon} /></span><div><strong>{item.label}</strong><p>{item.sub}</p></div><Icon name="chevron" size={18} />
            </Press>
          ))}
        </Card>
        <Card className="helpline-card"><span>24×7 CITIZEN HELPLINE</span><strong>1800-120-SEWA</strong><p>Available in English, Hindi & Marathi</p></Card>
        <div className="app-version"><Logo compact /><span>Version 2.4.1</span></div>
      </main>
      <BottomNav active="profile" go={go} />
    </div>
  );
}

function Comparison({ go }: { go: (s: Screen) => void }) {
  const [view, setView] = useState<"before" | "after">("after");
  return (
    <div className="screen comparison-screen">
      <StatusBar light />
      <main className="scroll-content comparison-content">
        <PageHeader title="Repair verification" subtitle="#SSP-239842 · Baner Road" back="tracking" go={go} />
        <div className="comparison-toggle">
          <Press className={view === "before" ? "active" : ""} onClick={() => setView("before")}>Before repair</Press>
          <Press className={view === "after" ? "active" : ""} onClick={() => setView("after")}>After repair</Press>
        </div>
        <div className={`repair-photo ${view}`}>
          <img
            src={view === "before"
              ? "https://images.unsplash.com/photo-1741996951019-a041d0477c82?auto=format&fit=crop&w=900&q=85"
              : "https://images.unsplash.com/photo-1648662594772-786f95b9e58b?auto=format&fit=crop&w=900&q=85"}
            alt={view === "before" ? "Damaged road before repair" : "Restored road after repair"}
          />
          <div className="photo-label"><span>{view === "before" ? "BEFORE · 18 FEB" : "AFTER · 20 FEB"}</span><small>PMC verified photo · GPS matched</small></div>
          <span className="photo-verified"><Icon name={view === "before" ? "camera" : "check"} size={17} /></span>
        </div>
        <Card className="repair-summary">
          <div className="repair-summary-head"><span className="repair-check"><Icon name="check" /></span><div><span className="eyebrow">AI + CITIZEN VERIFIED</span><h2>Repair quality passed</h2></div><strong>94%</strong></div>
          <p>Surface continuity and road level restored. No visible debris or open edges detected.</p>
          <div className="repair-metrics"><div><span>Completed in</span><strong>31 hours</strong></div><div><span>Work order</span><strong>₹18,450</strong></div><div><span>Warranty</span><strong>180 days</strong></div></div>
        </Card>
        <Card className="audit-row"><span><Icon name="shield" /></span><div><strong>Tamper-proof evidence</strong><p>Time, GPS and contractor details are secured in the public audit trail.</p></div><Icon name="chevron" size={18} /></Card>
      </main>
      <div className="action-footer comparison-actions"><Press className="primary-button" onClick={() => go("home")}><Icon name="check" size={18} /> Confirm repair quality</Press><Press className="footer-link" onClick={() => go("tracking")}>Report a concern</Press></div>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const go = (next: Screen) => setScreen(next);
  const pages: Record<Screen, ReactNode> = {
    splash: <Splash go={go} />,
    home: <Home go={go} />,
    report: <Report go={go} />,
    detection: <Detection go={go} />,
    tracking: <Tracking go={go} />,
    map: <RiskMap go={go} />,
    fund: <Fund go={go} />,
    notifications: <Notifications go={go} />,
    profile: <Profile go={go} />,
    comparison: <Comparison go={go} />,
  };
  return <div className="app-shell"><div className="phone-frame">{pages[screen]}</div></div>;
}
